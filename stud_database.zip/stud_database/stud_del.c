#include"header.h"

void delete_roll(ST**,int);
void delete_name(ST **, char*);
void delete_allrecord(ST **hptr)
{
	if(*hptr==0)
	{
		printf("No record available to delete\n");
		return ;
	}
	ST *temp;
	while(*hptr!=0)
	{
		temp=*hptr;
		*hptr=(*hptr)->next;
		free(temp);
	}
	printf("All Student record are deleted\n");
}
void delete_record(ST** hptr)
{
	if(*hptr==0)
	{
		printf("No record available to delete\n");
		return ;
	}
	int roll;
	char op,ch[50];
   	del_menu();
	printf("Enter your choice:");
	scanf(" %c",&op);
	if((op == 'r')||(op == 'R'))
	{
		printf("enter the roll no:");
		scanf("%d",&roll);
		delete_roll(&(*hptr),roll);
	}
	else if((op == 'n')||(op == 'N'))
	{
	         printf("enter Name:");
		 scanf(" %[^\n]s",ch);
		 delete_name(&(*hptr),ch);
	}
	else 
		printf("wrong option\n");
}

void delete_roll(ST **hptr,int roll)
{
    ST *ptr,*prev=NULL;
    char confirm;

    ptr=*hptr;

    while(ptr!=0)
    {
        if(ptr->rollno==roll)
        {
            printf("\nStudent Record Found\n");
            printf(" --------- ---------------------- ------------ \n");
	    printf("| %-7s | %-20s | %-10s |\n","ROLL NO","NAME","PERCENTAGE");
	    printf(" --------- ---------------------- ------------ \n");
	    printf("| %-7d | %-20s | %-10.2f |\n",ptr->rollno,ptr->name,ptr->mark);
            printf(" --------- ---------------------- ------------ \n");


            printf("Do you want to delete this record (Y/N): ");
            scanf(" %c",&confirm);

            if(confirm!='Y' && confirm!='y')
            {
                printf("Delete operation cancelled\n");
                return;
            }

            if(prev==NULL)
            {
                *hptr=ptr->next;
            }
            else
            {
                prev->next=ptr->next;
            }

            printf("Roll no %d %s is removed from the record\n",ptr->rollno,ptr->name);

            free(ptr);
            return;
        }

        prev=ptr;
        ptr=ptr->next;
    }

    printf("Roll no %d is not found\n",roll);
}

void delete_name(ST **hptr,char *p)
{
    int c=0,roll;
    ST *ptr;

    ptr=*hptr;

    while(ptr!=0)
    {
        if(strcmp(ptr->name,p)==0)
            c++;

        ptr=ptr->next;
    }

    ptr=*hptr;

    if(c>1)
    {
        printf("\n%d Data available with same name\n",c);
	printf(" --------- ---------------------- ------------ \n");
	printf("| %-7s | %-20s | %-10s |\n","ROLL NO","NAME","PERCENTAGE");
	printf(" --------- ---------------------- ------------ \n");

        while(ptr!=0)
        {
            if(strcmp(ptr->name,p)==0)
            {
		    printf("| %-7d | %-20s | %-10.2f |\n",ptr->rollno,ptr->name,ptr->mark);                 

            }

            ptr=ptr->next;
        }
        printf(" --------- ---------------------- ------------ \n");

        printf("Enter Roll No to Delete : ");
        scanf("%d",&roll);

        delete_roll(hptr,roll);
    }
    else if(c==1)
    {
        while(ptr!=0)
        {
            if(strcmp(ptr->name,p)==0)
            {
                delete_roll(hptr,ptr->rollno);
                return;
            }

            ptr=ptr->next;
        }
    }
    else
    {
        printf("%s record not found\n",p);
    }
}


